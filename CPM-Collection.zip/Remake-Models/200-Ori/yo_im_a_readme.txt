hey, this is my Ori model.
You are free to modify it and repost it or take part of it. (if you repost it with 0 changes, say my pseudo but if you change something, than it is yours)

this model was sugested by Rex Anivius#3891 on discord and i had nothing better to do so i made it and challenge myself to see how much custom animation i could put in it.

If you want you can ask me on discord (▄█▀zerustu▀█▄#0075) about how the model work, how i made it and all the files and tools.

This model is for 1.16 but if i have enough time, i will convert it to 1.12 (note that if i do, the climbing and the two custom animation with custom keys wont be ported).

▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

This model have a lot of custom animation : 450 line of javascript and a 69KB animation.js file (nice :) ).

there is a walking, runing and crouch walking animation, a jump/double jump(frontflip) animation, a climbing up/sliding down ladders animation and 2 customs animation (a spin and a custom pose) using the custom keys 1 and 2.

you can keep the custom keys 1 and 2 down to keep the custom animation running:
-keeping 1 down you  make the first model keep looping on the animation;
-keeping 2 down will freeze the model in the custom pose.
these two animation have the priority over any other animation and will stop them.

If you want to know, the animation are made in blockbench (the same tool to make the model) and then converted to javascript command using the tool : https://github.com/val9k/CPM_catmull_rom_interpolation

▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

also with the credit: 
thanks to the CPM creator Gamepiaynmo
thanks to art0007i#2305 for the shape of the head (i stol the head from his avali model. go check his model here https://discord.gg/2yjgSj2fMd)
thanks to Rex Anivius#3891 for the idea
and everyone one the CPM discord
