hey, this is my amaterasu model.
You are free to modify it and repost it. (if you repost it with 0 changes, say my pseudo but if you change something, than it is yours)

This model took time to go one the webpage because it was originally a quadriped model.
▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

this model have custom walking animation and arm swing animation.
if you have a bow, the mirror will be replace with a roserade and if you have a sword, it will be replace with a coresponding collor sword.

for this to work, you have to use the right hand and use vanilla weapons.

with the first custom model key, you can set issun to spawn on ama's head, presse it again to disable issun.

there is a lot of texture file and this model use multi texturing, and this is special because people will say that there is no multi texturing in 1.16 :p .

▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

The website doesn't handle quadriped skeleton, but the mod do. if you want, you can find the same model but using a quadriped skeleton. it is exatly the same model, but it have some info on how to make a model using a quadriped skeleton (eventho i don't really use it because of the swimming animation)
https://drive.google.com/file/d/1Fsb1IE3FRqgamarHQ9Xr2mnxGrYaasDj/view?usp=sharing

you can also find a 1.12 version of this model here (again, it is the exact same model), i don't know why but i can't upload it on the website.
https://drive.google.com/file/d/1oH7i7ocG7dcdaExzijtWBfR_fQ1rY7MC/view?usp=sharing

you can also find other of my model and a guide to help you create your own model here:
https://drive.google.com/drive/folders/1goGytWMPlLziG48k-2aSqvFmEFXRD7pT?usp=sharing

▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

also with the credit: 
thanks to DearFox for his interpolation animation tool
and thanks to the CPM creator : Gamepiaynmo
and everyone on the discord server