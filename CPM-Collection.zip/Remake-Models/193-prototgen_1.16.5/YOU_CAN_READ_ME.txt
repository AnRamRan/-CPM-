hey, this is my protogen model.
You are free to modify it and repost it. (if you repost it with 0 changes, say my pseudo but if you change something, than it is yours)

there is multiple texture (5 for by default) and you can add more (in the animation file, add the name of the texture in the "textures" list).
CPM custom key alows you to swap between the texture during gameplay.
the first 5 are spetial : 
1 - default skin
2 - skin use when hurt
3 - sad
4-  angry
5 - shock

3, 4 and 5 have special ear position (set in the end of the anim file).


▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

also with the credit: 
thanks to DearFox for his interpolation animation tool
and thanks to the CPM creator
and everyone on the discord server