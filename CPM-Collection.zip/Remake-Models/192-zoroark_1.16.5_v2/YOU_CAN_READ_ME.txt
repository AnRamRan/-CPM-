hey, this is my zoroark model.
You are free to modify it and repost it. (if you repost it with 0 changes, say my pseudo but if you change something, than it is yours)

▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄

also with the credit: 
thanks to DearFox for his interpolation animation tool
and thanks to the CPM creator
and everyone on the discord server